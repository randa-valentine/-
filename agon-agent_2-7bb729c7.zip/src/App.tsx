import { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';

// Scene configuration
const SCENES = [
  { 
    text: 'In the quiet of the night...', 
    cameraZ: 50,
    particleIntensity: 0.3,
    glowIntensity: 0.2
  },
  { 
    text: 'a moment arrives...', 
    cameraZ: 40,
    particleIntensity: 0.5,
    glowIntensity: 0.3
  },
  { 
    text: 'that changes everything.', 
    cameraZ: 30,
    particleIntensity: 0.7,
    glowIntensity: 0.4
  },
  { 
    text: 'Time whispers...', 
    cameraZ: 20,
    particleIntensity: 0.8,
    glowIntensity: 0.5
  },
  { 
    text: 'and stars align...', 
    cameraZ: 10,
    particleIntensity: 0.9,
    glowIntensity: 0.6
  },
  { 
    text: 'for someone special.', 
    cameraZ: 5,
    particleIntensity: 1.0,
    glowIntensity: 0.7
  },
  { 
    text: '20', 
    cameraZ: 0,
    particleIntensity: 1.2,
    glowIntensity: 1.0,
    isNumber: true
  },
  { 
    text: 'Two decades of light', 
    cameraZ: -5,
    particleIntensity: 1.0,
    glowIntensity: 0.8
  },
  { 
    text: 'A journey of a thousand dreams', 
    cameraZ: -10,
    particleIntensity: 0.8,
    glowIntensity: 0.6
  },
  { 
    text: 'And this is just the beginning...', 
    cameraZ: -15,
    particleIntensity: 0.6,
    glowIntensity: 0.4
  },
  { 
    text: 'Happy Birthday', 
    cameraZ: -20,
    particleIntensity: 1.5,
    glowIntensity: 1.2,
    isFinale: true
  },
  { 
    text: 'May your light shine forever ✨', 
    cameraZ: -25,
    particleIntensity: 0.3,
    glowIntensity: 0.2,
    isEnd: true
  }
];

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const particlesRef = useRef<THREE.Points | null>(null);
  const textGroupRef = useRef<THREE.Group | null>(null);
  const numberGroupRef = useRef<THREE.Group | null>(null);
  const animationRef = useRef<number>(0);
  const clockRef = useRef<THREE.Clock>(new THREE.Clock());
  
  const [currentScene, setCurrentScene] = useState(0);
  const [displayedText, setDisplayedText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showScrollHint, setShowScrollHint] = useState(true);
  const [isLoaded, setIsLoaded] = useState(false);
  const scrollProgressRef = useRef(0);
  const targetCameraZRef = useRef(50);

  // Initialize Three.js scene
  useEffect(() => {
    if (!canvasRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x0a0a1a, 0.015);
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.z = 50;
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      antialias: true,
      alpha: true
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x050510, 1);
    rendererRef.current = renderer;

    // Create particle system
    const particleCount = 3000;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    const sizes = new Float32Array(particleCount);

    const colorPalette = [
      new THREE.Color(0x9d4edd), // Purple
      new THREE.Color(0x5a189a), // Deep purple
      new THREE.Color(0x3c096c), // Midnight
      new THREE.Color(0x7b2cbf), // Light purple
      new THREE.Color(0xe0aaff), // Soft lavender
    ];

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 100;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 100;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 100;

      const color = colorPalette[Math.floor(Math.random() * colorPalette.length)];
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;

      sizes[i] = Math.random() * 2 + 0.5;
    }

    const particleGeometry = new THREE.BufferGeometry();
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    particleGeometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));

    // Custom shader material for particles
    const particleMaterial = new THREE.ShaderMaterial({
      uniforms: {
        time: { value: 0 },
        intensity: { value: 0.3 },
      },
      vertexShader: `
        attribute float size;
        attribute vec3 color;
        varying vec3 vColor;
        uniform float time;
        uniform float intensity;
        
        void main() {
          vColor = color;
          vec3 pos = position;
          pos.x += sin(time * 0.5 + position.y * 0.1) * intensity * 2.0;
          pos.y += cos(time * 0.3 + position.x * 0.1) * intensity * 2.0;
          pos.z += sin(time * 0.4 + position.z * 0.1) * intensity;
          
          vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
          gl_PointSize = size * (200.0 / -mvPosition.z) * intensity;
          gl_Position = projectionMatrix * mvPosition;
        }
      `,
      fragmentShader: `
        varying vec3 vColor;
        
        void main() {
          float dist = length(gl_PointCoord - vec2(0.5));
          if (dist > 0.5) discard;
          
          float alpha = 1.0 - smoothstep(0.0, 0.5, dist);
          alpha *= 0.8;
          
          vec3 glow = vColor * 1.5;
          gl_FragColor = vec4(glow, alpha);
        }
      `,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);
    particlesRef.current = particles;

    // Create text group
    const textGroup = new THREE.Group();
    scene.add(textGroup);
    textGroupRef.current = textGroup;

    // Create number group for "20"
    const numberGroup = new THREE.Group();
    scene.add(numberGroup);
    numberGroupRef.current = numberGroup;

    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0x9d4edd, 0.3);
    scene.add(ambientLight);

    // Add point lights
    const light1 = new THREE.PointLight(0x9d4edd, 2, 50);
    light1.position.set(10, 10, 10);
    scene.add(light1);

    const light2 = new THREE.PointLight(0x5a189a, 2, 50);
    light2.position.set(-10, -10, 10);
    scene.add(light2);

    // Handle resize
    const handleResize = () => {
      if (!camera || !renderer) return;
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // Animation loop
    const animate = () => {
      animationRef.current = requestAnimationFrame(animate);
      
      const time = clockRef.current.getElapsedTime();
      
      // Update particle shader
      if (particlesRef.current) {
        const material = particlesRef.current.material as THREE.ShaderMaterial;
        material.uniforms.time.value = time;
        material.uniforms.intensity.value = SCENES[currentScene]?.particleIntensity || 0.3;
      }
      
      // Smooth camera movement
      if (cameraRef.current) {
        cameraRef.current.position.z += (targetCameraZRef.current - cameraRef.current.position.z) * 0.05;
      }
      
      // Rotate number group
      if (numberGroupRef.current) {
        numberGroupRef.current.rotation.y = Math.sin(time * 0.5) * 0.3;
      }
      
      // Rotate particles slowly
      if (particlesRef.current) {
        particlesRef.current.rotation.y = time * 0.02;
        particlesRef.current.rotation.x = time * 0.01;
      }
      
      renderer.render(scene, camera);
    };
    
    animate();
    
    // Fade in
    setTimeout(() => setIsLoaded(true), 500);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationRef.current);
      renderer.dispose();
    };
  }, []);

  // Typewriter effect
  const typeText = useCallback((text: string, callback?: () => void) => {
    setIsTyping(true);
    setDisplayedText('');
    let index = 0;
    
    const interval = setInterval(() => {
      if (index < text.length) {
        setDisplayedText(text.substring(0, index + 1));
        index++;
      } else {
        clearInterval(interval);
        setIsTyping(false);
        callback?.();
      }
    }, 80);
    
    return () => clearInterval(interval);
  }, []);

  // Handle scene change
  useEffect(() => {
    const scene = SCENES[currentScene];
    if (!scene) return;

    targetCameraZRef.current = scene.cameraZ;
    
    if (scene.isNumber) {
      // Show "20" with special effect
      setDisplayedText('');
      createNumber20();
    } else {
      // Clear number group if not number scene
      if (numberGroupRef.current) {
        numberGroupRef.current.clear();
      }
      typeText(scene.text);
    }

    // Track interaction
    fetch('/api/interactions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        scroll_progress: scrollProgressRef.current,
        current_scene: currentScene
      })
    }).catch(() => {});
  }, [currentScene, typeText]);

  // Create "20" from particles
  const createNumber20 = useCallback(() => {
    if (!numberGroupRef.current || !sceneRef.current) return;
    
    numberGroupRef.current.clear();
    
    // Create "2"
    const createDigit = (digit: string, offsetX: number) => {
      const group = new THREE.Group();
      
      // Simple representation using spheres
      const points = digit === '2' ? [
        [0, 2, 0], [1, 2, 0], [2, 2, 0],
        [2, 1, 0],
        [2, 0, 0], [1, 0, 0], [0, 0, 0],
        [0, -1, 0],
        [0, -2, 0], [1, -2, 0], [2, -2, 0],
      ] : [ // "0"
        [0, 2, 0], [1, 2, 0], [2, 2, 0],
        [0, 1, 0], [2, 1, 0],
        [0, 0, 0], [2, 0, 0],
        [0, -1, 0], [2, -1, 0],
        [0, -2, 0], [1, -2, 0], [2, -2, 0],
      ];
      
      points.forEach(([x, y, z]) => {
        const geometry = new THREE.SphereGeometry(0.3, 16, 16);
        const material = new THREE.MeshBasicMaterial({
          color: 0xe0aaff,
          transparent: true,
          opacity: 0.9
        });
        const sphere = new THREE.Mesh(geometry, material);
        sphere.position.set(x * 1.2 + offsetX, y * 1.2, z);
        group.add(sphere);
        
        // Add glow
        const glowGeometry = new THREE.SphereGeometry(0.5, 16, 16);
        const glowMaterial = new THREE.MeshBasicMaterial({
          color: 0x9d4edd,
          transparent: true,
          opacity: 0.3
        });
        const glow = new THREE.Mesh(glowGeometry, glowMaterial);
        glow.position.copy(sphere.position);
        group.add(glow);
      });
      
      return group;
    };
    
    const digit2 = createDigit('2', -4);
    const digit0 = createDigit('0', 2);
    
    numberGroupRef.current.add(digit2);
    numberGroupRef.current.add(digit0);
    numberGroupRef.current.position.z = -5;
  }, []);

  // Handle scroll/touch
  const handleScroll = useCallback((e: React.WheelEvent | React.TouchEvent) => {
    if (isTyping) return;
    
    let delta = 0;
    if ('deltaY' in e) {
      delta = e.deltaY > 0 ? 1 : -1;
    } else if ('touches' in e) {
      const touch = e.touches[0];
      const lastTouch = (e.target as HTMLElement).dataset.lastTouch;
      if (lastTouch) {
        delta = touch.clientY - parseFloat(lastTouch) > 0 ? -1 : 1;
      }
      (e.target as HTMLElement).dataset.lastTouch = touch.clientY.toString();
    }
    
    if (delta > 0 && currentScene < SCENES.length - 1) {
      setCurrentScene(prev => prev + 1);
      scrollProgressRef.current += 1;
      setShowScrollHint(false);
    } else if (delta < 0 && currentScene > 0) {
      setCurrentScene(prev => prev - 1);
      scrollProgressRef.current -= 1;
    }
  }, [currentScene, isTyping]);

  // Touch start handler
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    const touch = e.touches[0];
    (e.target as HTMLElement).dataset.lastTouch = touch.clientY.toString();
  }, []);

  const scene = SCENES[currentScene];
  const isNumberScene = scene?.isNumber;
  const isFinale = scene?.isFinale;
  const isEnd = scene?.isEnd;

  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 overflow-hidden bg-[#050510]"
      onWheel={handleScroll}
      onTouchMove={handleScroll}
      onTouchStart={handleTouchStart}
    >
      {/* Three.js Canvas */}
      <canvas 
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
      />
      
      {/* Loading Overlay */}
      <div 
        className={`absolute inset-0 bg-[#050510] flex items-center justify-center transition-opacity duration-1000 pointer-events-none ${
          isLoaded ? 'opacity-0' : 'opacity-100'
        }`}
      >
        <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
      </div>
      
      {/* Text Overlay */}
      <div 
        className={`absolute inset-0 flex items-center justify-center pointer-events-none transition-opacity duration-500 ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        }`}
      >
        {!isNumberScene && (
          <div 
            className={`text-center px-8 transition-all duration-700 ${
              isFinale 
                ? 'scale-125' 
                : isEnd 
                  ? 'scale-100 opacity-80' 
                  : 'scale-100'
            }`}
          >
            <h1 
              className={`font-light tracking-wider transition-all duration-500 ${
                isFinale 
                  ? 'text-5xl md:text-7xl text-transparent bg-clip-text bg-gradient-to-r from-purple-300 via-pink-300 to-purple-300'
                  : isEnd
                    ? 'text-2xl md:text-3xl text-purple-300/70'
                    : 'text-3xl md:text-5xl text-purple-200'
              }`}
              style={{
                textShadow: '0 0 30px rgba(157, 78, 221, 0.5)',
                fontFamily: 'system-ui, -apple-system, sans-serif'
              }}
            >
              {displayedText}
              {isTyping && (
                <span className="inline-block w-0.5 h-6 md:h-8 bg-purple-300 ml-1 animate-pulse" />
              )}
            </h1>
          </div>
        )}
        
        {/* "20" Text Fallback */}
        {isNumberScene && (
          <div className="text-center">
            <div 
              className="text-8xl md:text-[12rem] font-extralight text-transparent bg-clip-text bg-gradient-to-b from-purple-200 via-purple-400 to-purple-600 animate-pulse"
              style={{
                textShadow: '0 0 60px rgba(157, 78, 221, 0.8), 0 0 120px rgba(157, 78, 221, 0.4)',
                fontFamily: 'system-ui, -apple-system, sans-serif'
              }}
            >
              20
            </div>
          </div>
        )}
      </div>
      
      {/* Scroll Hint */}
      {showScrollHint && isLoaded && (
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
          <span className="text-purple-400/60 text-sm tracking-widest uppercase">Scroll</span>
          <svg 
            className="w-6 h-6 text-purple-400/60" 
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M19 14l-7 7m0 0l-7-7m7 7V3" 
            />
          </svg>
        </div>
      )}
      
      {/* Progress Indicator */}
      <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col gap-2">
        {SCENES.map((_, index) => (
          <div
            key={index}
            className={`w-1 h-6 rounded-full transition-all duration-300 ${
              index === currentScene 
                ? 'bg-purple-400 scale-125' 
                : index < currentScene 
                  ? 'bg-purple-400/50' 
                  : 'bg-purple-400/20'
            }`}
          />
        ))}
      </div>
      
      {/* Ambient Gradient Overlay */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(circle at 50% 50%, transparent 0%, rgba(5, 5, 16, 0.3) 50%, rgba(5, 5, 16, 0.8) 100%)`
        }}
      />
      
      {/* Vignette Effect */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          boxShadow: 'inset 0 0 150px rgba(0, 0, 0, 0.8)'
        }}
      />
    </div>
  );
}